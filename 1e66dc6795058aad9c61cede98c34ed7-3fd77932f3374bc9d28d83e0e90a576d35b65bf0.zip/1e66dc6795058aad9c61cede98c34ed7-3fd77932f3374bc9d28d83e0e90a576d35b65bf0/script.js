function registerNow() {
    alert("Thanks for your interest! Registration opens soon.");
    // You can redirect: window.location.href = "https://yourdanceevent.com/register";
}
